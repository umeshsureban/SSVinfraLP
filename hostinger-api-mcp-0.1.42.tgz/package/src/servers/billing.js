#!/usr/bin/env node
// Auto-generated entry for group: billing
import { startServer } from '../core/runtime.js';
import tools from '../core/tools/billing.js';

startServer({ name: 'hostinger-billing-mcp', version: '0.1.42', tools });
